In the menupages folder place the following when complete (in folders ideally):
- Slide-in menu
- Open Courses
- Course Catalog
- Games
- Library
- Notifications (will review if this should go in menupages)
- Account Settings
- Privacy Policy
- Help
