// COURSES HOME PAGE LOGIC GOES HERE.
// Notes:
//   - Rename Courses.js based on naming conventions after it is decided on (i.e. capitalizations for styles, main, and js files)
//   - Don't put everything in one file. Seperate into:
//       - Styles
//       - Logic (Main .js file)
//       - APIs (Accessory .js files)
