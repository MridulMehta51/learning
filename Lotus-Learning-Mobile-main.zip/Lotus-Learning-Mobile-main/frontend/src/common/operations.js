// COMMON OPERATIONS
//    - May prove redundant in future, BUT will ideally be used for operations and APIs used between several modules. Getting user data or date is an example.
